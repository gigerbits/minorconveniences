#import
import random
#define elements
GROUP1 = ['Crab', 'Scorpion', 'Beetle']
GROUP2 = ['Embossed', 'Debossed', 'Flat']
GROUP3 = ['Ring', 'No Ring', 'Half Ring']

COMBINED_LIST = GROUP1 + GROUP2 + GROUP3
list_length = len(COMBINED_LIST)-1
#create the unique quality
def unique_q():
    x = random.randint(0, list_length)
    y = COMBINED_LIST[x]
    return y
#create random values for the other
def random_q(z, n):
    group1 = GROUP1.copy()
    group2 = GROUP2.copy()
    group3 = GROUP3.copy()
    megalist = []
    x = 0
    for i in (range(len(group1))):
        if group1[i] == z:
            megalist.append([z, random.choice(group2), random.choice(group3)])
            group1.pop(i)
            x = 3
            choice3 = megalist[0][2]
            break
        if group2[i] == z:
            megalist.append([random.choice(group1), z, random.choice(group3)])
            group2.pop(i)
            x = 1
            choice1 = megalist[0][0]
            break
        if group3[i] == z:
            megalist.append([random.choice(group1), random.choice(group2), z])
            group3.pop(i)
            x = 2
            choice2 = megalist[0][1]
            break
    for i in range(n-1):
        if i != 0:
            x = random.randint(1, 3)
        if x != 1:
            choice1 = random.choice(group1)
        if x != 2:
            choice2 = random.choice(group2)
        if x != 3:
            choice3 = random.choice(group3)
        megalist.append([choice1, choice2, choice3])
    print(megalist)
    return megalist
def unique_full(u):
    group1 = GROUP1.copy()
    group2 = GROUP2.copy()
    group3 = GROUP3.copy()
    unique_group = []
    for i in range(len(group1)):
        if group1[i] == u:
            
            break

        if group2[i] == u:
            
            break

        if group3[i] == u:
            
            break

    return unique_group




#define main function
def main():
    while True:
        print('Random Quality Generator')
        print('------------------------')
        print()
        print()
        print()
        print('Enter the quantity you want to generate')
        print('---------------------------------------')
        while True:
            quantity = input('Enter the Quantity: ')
            print()
            print()
            print('Total number selected: ' + quantity)
            print()
            if not quantity.isdigit():
                print("Please enter a valid number.")
            else:
                print('Generating...')
                break
        
        total = int(quantity)
        quality = unique_q()
        qualities = random_q(quality, total)
        print('Unique Quality: ' + quality)
        print(qualities[0])
        random.shuffle(qualities)
        print('Groups: ')
        for i in range(len(qualities)):
            print(qualities[i])
        m = input('Press Enter to continue, or type "exit" to quit: ')
        if m == 'exit':
            break

        

#run the function
main()
#TEMP
#for i in range(1):
#    g = 5
#    v = unique_q()
#    print(random_q(v, g))
#    print(v)
#    print('---')
